import { getStore } from "@netlify/blobs";

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });

export default async (req) => {
  const store = getStore("el-gordito");

  if (req.method === "GET") {
    return json(await store.get("cardapio", { type: "json" }));
  }

  if (req.method === "POST") {
    const senha = process.env.ADMIN_PASSWORD;
    if (!senha || req.headers.get("x-admin-password") !== senha) {
      return new Response("Senha incorreta", { status: 401 });
    }
    let body;
    try { body = await req.json(); } catch { return new Response("JSON inválido", { status: 400 }); }
    if (!body || !Array.isArray(body.m) || JSON.stringify(body).length > 100000) {
      return new Response("Dados inválidos", { status: 400 });
    }
    await store.setJSON("cardapio", body);
    return new Response("ok");
  }

  return new Response("Método não permitido", { status: 405 });
};

export const config = { path: "/api/cardapio" };
