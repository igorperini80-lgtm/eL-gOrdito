# Formulário de eventos eL gOrdito no Netlify

## Como publicar (uma vez)
O salvamento usa uma função do Netlify, então a pasta precisa ser publicada por Git ou pelo CLI. Arrastar a pasta no "Netlify Drop" NÃO ativa a função.

**Pelo GitHub (mais fácil de manter)**
1. Crie um repositório no GitHub e envie o conteúdo desta pasta.
2. No Netlify: Add new site > Import an existing project > escolha o repositório. Não precisa preencher build command.
3. Em Site configuration > Environment variables, crie `ADMIN_PASSWORD` com a senha que só você vai usar.
4. Faça um novo deploy (Deploys > Trigger deploy).

**Pelo terminal**
```
npm i -g netlify-cli
netlify login
netlify init
netlify env:set ADMIN_PASSWORD "sua-senha"
netlify deploy --prod
```

## Como editar e salvar
1. Abra `https://SEU-SITE.netlify.app/#admin` e toque em "Editar cardápio e valores".
2. Altere pratos, carnes, valores, garçom e o WhatsApp (com DDD).
3. Digite a senha de administrador e toque em Salvar.
O cardápio fica guardado no Netlify e vale para todos os clientes. Clientes não veem o link de edição.

## Enviar ao cliente
Na tela de edição, o botão "Enviar o formulário a um cliente pelo WhatsApp" já monta a mensagem com o link do site.
